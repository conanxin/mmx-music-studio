# MiniMax 音乐创作台 / mmx-music-studio

**开源、自托管、BYOK 的 MiniMax 音乐生成网站**

> ⚠️ **免责声明**：这是一个非官方的开源项目，与 MiniMax 无任何关联。

## 项目目标

打造一个简约、有设计感、中文界面的音乐创作工具，让用户通过自己的 MiniMax Token Plan Key 生成音乐、在线试听、下载 MP3、管理历史作品。

## 功能规划

- 🎵 **纯音乐 / BGM** — 文字描述生成背景音乐
- 🎤 **自动写歌词并生成歌曲** — 输入主题，自动写词+作曲
- ✍️ **歌词成歌** — 提供自己的歌词，生成完整歌曲
- 🔄 **参考音频 Cover / 改编** — 上传参考音频进行风格改编
- ▶️ **在线试听** — 波形播放器，无需下载即可播放
- 💾 **下载 MP3** — 一键保存高质量 MP3 文件
- 📚 **作品库** — 历史作品管理，随时回听

## 当前阶段

**Phase 2D：MMX CLI Adapter** — API 直连遇到服务侧错误，已切换到 CLI Adapter

- `server/adapters/minimax-cli/` — MMX CLI 生成适配
- `MINIMAX_BACKEND=mock/api/cli` 三选一
- 默认 `MINIMAX_BACKEND=mock`（安全本地模拟）

## 技术栈

- React 18 + TypeScript
- Vite 5
- React Router v6
- CSS Modules / Vanilla CSS（无 Tailwind，无复杂依赖）

## 快速启动

```bash
# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev

# 构建生产版本
pnpm build
```

本地访问地址：http://localhost:5174

## 界面预览

本阶段为静态 UI 原型，截图均为 Mock 页面，不调用真实 API，不包含任何真实密钥。

| 资源 | 路径 |
|------|------|
| 设计评审页（HTML） | `docs/screenshots/review.html` |
| 截图拼贴总览图 | `docs/screenshots/contact-sheet.png` |
| 截图源文件 | `docs/screenshots/*.png` |
| 设计评审打包 | `docs/mmx-music-studio-ui-review.zip` |

> ⚠️ 截图为 Mock UI，不调用真实 MiniMax API。真实 API 接入将在后续阶段完成。

## 项目结构

```
mmx-music-studio/
├── apps/
│   └── web/              # Web 前端应用
├── packages/
│   ├── core/             # 平台无关核心逻辑
│   ├── adapters/         # 平台适配器（storage/audio/api）
│   └── ui-tokens/        # 设计令牌
├── docs/                 # 项目文档
├── storage/              # 本地存储（作品文件）
└── README.md
```

## 微信小程序准备

项目从第一天起就考虑了微信小程序迁移：

- 业务逻辑全在 `packages/core`（平台无关）
- API 调用通过 `packages/adapters` 适配
- UI 组件小程序端用 Taro / uni-app 接入
- 不依赖浏览器专有 API

详见 [docs/MINIPROGRAM-READY.md](./docs/MINIPROGRAM-READY.md)

## 安全原则

### 开发模式（默认）

默认 `REAL_GENERATION_ENABLED=false`，即使配置了 `MINIMAX_API_KEY` 也不会调用真实 MiniMax API，而是使用本地 Mock 生成（sine wave WAV 文件）。所有 smoke test 均在此模式下运行，**不消耗额度**。

### 真实生成模式

需要显式开启：

```bash
REAL_GENERATION_ENABLED=true
MINIMAX_BACKEND=cli   # 推荐：使用 mmx CLI（需先 mmx auth login）
# 或
MINIMAX_BACKEND=api   # 实验性：直接调用 MiniMax API（Phase 2C 发现服务可能返回错误）
PUBLIC_DEMO_MODE=false
MINIMAX_API_KEY=***
```

CLI Adapter 推荐原因：不通过 HTTP 直连 MiniMax，由 mmx CLI 管理认证和请求。

详见 [docs/SECURITY.md](./docs/SECURITY.md)

## 开源协议

MIT License

---

**Unofficial open-source project. Not affiliated with MiniMax.**