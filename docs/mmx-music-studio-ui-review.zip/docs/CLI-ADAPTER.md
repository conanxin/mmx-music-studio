# MMX CLI Adapter — Phase 2D

## 状态

**Phase 2D** — CLI Adapter 已实现，待 Phase 2D-B 用户确认后执行首次真实生成。

---

## 架构

```
server/adapters/minimax-cli/
├── index.ts        — 导出
├── client.ts        — generateWithMmxCli() / diagnoseMmxCli()
├── errors.ts        — MmxCliError 家族 + redactCliOutput()
└── types.ts        — 类型定义
```

---

## mmx CLI 现状（Phase 2D 执行时检查）

**注意**：当前 shell 环境的 mmx CLI 存在配置问题（`Invalid URL protocol` 错误），所有命令包括 `--help` 均失败。这可能是因为 `~/.mmx/config.json` 中的 `api_key` 字段为空或格式异常。

```
which mmx    → /home/ubuntu/.npm-global/bin/mmx
mmx version  → 1.0.16
auth status  → Error: Invalid URL protocol
config show  → Error: Invalid URL protocol
quota        → Error: Invalid URL protocol
```

建议：在真正执行 MMX CLI 生成前，需要先解决 mmx auth 问题。

---

## CLI Adapter 特性

### 安全设计

- **不传 API key via CLI**：不使用 `MINIMAX_API_KEY="..." mmx ...`（会进入 shell history）
- **不传 API key via process.env**：spawn 时不注入 `MINIMAX_API_KEY` env 变量
- **依赖 mmx 自有认证**：`~/.mmx/config.json` 中的 api_key 由 mmx CLI 自己加载
- **参数数组传递**：spawn 用数组，不用 shell 拼接（防注入）
- **stdout/stderr 脱敏**：`redactCliOutput()` 移除 key/Bearer/sk-/token
- **不记录完整输出**：只保存 stderr preview 前 2000 字符

### 支持的模式

| 模式 | 支持 | 命令 |
|------|------|------|
| `instrumental` | ✅ | `mmx music generate --prompt ... --instrumental --out ...` |
| `auto` | ✅ | `mmx music generate --prompt ... --lyrics-optimizer --out ...` |
| `lyrics` | ✅ | `mmx music generate --prompt ... --lyrics "..." --out ...` |
| `cover-url` | ✅ | `mmx music cover --prompt ... --audio <url> --out ...` |
| `cover-file` | ❌ | Phase 2D 暂不支持（Web 上传用 base64） |

### 参数说明

```typescript
generateWithMmxCli(input, {
  outputDir: string,      // 必填，输出目录
  timeoutMs?: number,     // 默认 180000ms
  region?: 'cn' | 'global',
  audioUrl?: string,      // cover-url 模式必需
  audioFile?: string,     // cover-file 模式（Phase 2D 不可用）
})
```

### 错误类型

| 错误类型 | code | 说明 |
|----------|------|------|
| `MmxCliNotFoundError` | `CLI_NOT_FOUND` | mmx 不在 PATH 中 |
| `MmxCliTimeoutError` | `TIMEOUT` | 生成超时 |
| `MmxCliAuthError` | `AUTH_FAILED` | 未登录或认证过期 |
| `MmxCliUnsupportedModeError` | `UNSUPPORTED_MODE` | 不支持的模式 |
| `MmxCliGenerationError` | `GENERATION_FAILED` | 生成失败 |

---

## Phase 2D-B：启用 CLI 生成

当用户确认要执行真实 CLI 生成时，按以下步骤操作：

### 1. 确认 mmx auth 有效

```bash
# 在项目目录执行（不传 key，避免 shell history）
mmx auth status
mmx quota
```

如果 auth 失败，先修复 mmx 配置再继续。

### 2. 启动 CLI 模式 server

```bash
cd /home/ubuntu/projects/mmx-music-studio

# 停止现有 server
pkill -f "tsx server/index.ts" 2>/dev/null || true
sleep 2

# 启动 CLI 真实模式（REAL_GENERATION_ENABLED=true 且 MINIMAX_BACKEND=cli）
REAL_GENERATION_ENABLED=true \
MINIMAX_BACKEND=cli \
MOCK_GENERATION_ENABLED=false \
npm run dev:server
```

### 3. 单次生成测试

```bash
curl -s -X POST http://localhost:8787/api/generate \
  -H 'Content-Type: application/json' \
  -d '{
    "keyMode": "server",
    "input": {
      "mode": "instrumental",
      "prompt": "warm ambient electronic, calm, focused"
    }
  }'
```

### 4. 验证结果

- 如果 `generationSource: "mmx-cli"`，说明 CLI adapter 正常工作
- 如果失败，检查 `/api/debug/cli` 端点获取 mmx 状态

### 5. 切回安全模式

```bash
kill $(lsof -ti :8787) 2>/dev/null || true
sleep 1
```

---

## API 端点

### GET /api/debug/cli

安全模式下的 CLI 诊断端点（`REAL_GENERATION_ENABLED=false` 时可用）。

返回：
```json
{
  "ok": true,
  "mmxAvailable": true,
  "version": "1.0.16",
  "authStatusSafe": "authenticated",
  "regionSafe": "cn",
  "quotaAvailable": true,
  "musicGenerateHelpPreview": "...",
  "musicCoverHelpPreview": "..."
}
```

---

## API Adapter vs CLI Adapter

| 特性 | API Adapter | CLI Adapter |
|------|------------|------------|
| 依赖 | `MINIMAX_API_KEY` env | mmx auth (`~/.mmx/config.json`) |
| 请求方式 | HTTP POST 直接调 MiniMax | spawn mmx CLI 子进程 |
| 进度追踪 | 需要自己实现轮询 | mmx CLI 自己管理 |
| 错误处理 | HTTP 状态码 + MiniMax 错误码 | process exit code |
| 适用场景 | 自托管后端 | 有 mmx CLI 的用户 |
| Phase 2C 状态 | 服务端返回"准备失败"错误 | 未测试（mmx auth 有问题） |
| Phase 2D 状态 | experimental | 已实现，待 2D-B 测试 |

---

## 不泄露内容

以下内容永远不会出现在日志或响应中：
- API key / Bearer token / Authorization header
- `sk-` 开头的 key
- 完整的 `Authorization: Bearer xxx` 值
- `MINIMAX_API_KEY=xxx` 形式
- `~/.mmx/config.json` 的 api_key 字段内容
- MiniMax 响应中的签名 URL（仅记录域名部分）

---

## 下一步

1. **解决 mmx auth 问题** — 检查 `~/.mmx/config.json` 的 api_key 格式
2. **Phase 2D-B** — 用户确认后执行单次真实 CLI 生成
3. 如果 CLI 也失败，可能是该 key 本身无音乐生成权限
